

<?php $__env->startSection('css'); ?>
 
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css' rel='stylesheet' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Calendario de Citas</h2>
        <div id='calendar'></div> 
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js'></script>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'es', // Localización en español
        events: '<?php echo e(route('calendario.citas')); ?>', // Ruta que devuelve el JSON de las citas

        eventClick: function(info) {
            alert('Cita: ' + info.event.title); // Muestra una alerta al hacer clic en un evento
        },

        // Depuración: ver los eventos cargados
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch('<?php echo e(route('calendario.citas')); ?>')
                .then(response => response.json())
                .then(events => {
                    console.log("Eventos cargados:", events);  // Aquí puedes ver si los eventos se cargan
                    successCallback(events);
                })
                .catch(error => {
                    console.error('Error al cargar eventos:', error);
                    failureCallback(error);
                });
        }
    });

    calendar.render();
});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\calendario_index.blade.php ENDPATH**/ ?>