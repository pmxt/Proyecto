

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Antecedentes obstétricos</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(isset($currentStep) && isset($totalSteps)): ?>
    <?php
        $progress = ($currentStep / $totalSteps) * 100;
    ?>
    <div class="progress mb-4">
        <div class="progress-bar" role="progressbar" style="width: <?php echo e($progress); ?>%;" 
            aria-valuenow="<?php echo e($progress); ?>" aria-valuemin="0" aria-valuemax="100">
            Paso <?php echo e($currentStep); ?> de <?php echo e($totalSteps); ?>

        </div>
    </div>
<?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('antecedentes.submit', ['embarazo_id' => $embarazo->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="embarazo_id" value="<?php echo e($embarazo->id); ?>">
           

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>No. Embarazos</label>
                    <input type="number" name='num_embarazos' class="form-control"
                        value="<?php echo e(old('num_embarazos', $datos['num_embarazos'] ?? '')); ?>" required>
                </div>
                <div class="form-group col-md-4">
                    <label>No. Partos</label>
                    <input type="number" name='num_partos' class="form-control"
                        value="<?php echo e(old('num_partos', $datos['num_partos'] ?? '')); ?>" required>
                </div>
                <div class="form-group col-md-4">
                    <label>No. Cesáreas</label>
                    <input type="number" name='num_cesarias' class="form-control"
                        value="<?php echo e(old('num_cesarias', $datos['num_cesarias'] ?? '')); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>No. Abortos</label>
                    <input type="number" name="num_abortos" class="form-control"
                        value="<?php echo e(old('num_abortos', $datos['num_abortos'] ?? '')); ?>" required>
                </div>
                <div class="form-group col-md-4">
                    <label>No. Hijos nacidos vivos</label>
                    <input type="number" name="num_hijos_nacidos_vivos" class="form-control"
                        value="<?php echo e(old('num_hijos_nacidos_vivos', $datos['num_hijos_nacidos_vivos'] ?? '')); ?>" required>
                </div>
                <div class="form-group col-md-4">
                    <label>No. Hijos nacidos muertos</label>
                    <input type="number" name="num_hijos_nacidos_muertos" class="form-control"
                        value="<?php echo e(old('num_hijos_nacidos_muertos', $datos['num_hijos_nacidos_muertos'] ?? '')); ?>" required>
                </div>
                <div class="form-group col-md-4">
                    <label>No. Hijos vivos</label>
                    <input type="number" name="num_hijos_vivos" class="form-control"
                        value="<?php echo e(old('num_hijos_vivos', $datos['num_hijos_vivos'] ?? '')); ?>" required>
                </div>
                <div class="form-group col-md-4">
                    <label>No. Hijos fallecidos</label>
                    <input type="number" name="num_hijos_fallecidos" class="form-control"
                        value="<?php echo e(old('num_hijos_fallecidos', $datos['num_hijos_fallecidos'] ?? '')); ?>" required>
                </div>
            </div>
            
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Descripción</th>
                        <th>A</th>
                        <th>B</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Muerte fetal o neonatal previa</td>
                        <td><input type="radio" name="muerte_fetal" value="si" <?php echo e(old('muerte_fetal') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="muerte_fetal" value="no" <?php echo e(old('muerte_fetal') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Antecedentes de 3 o más abortos espontáneos consecutivos</td>
                        <td><input type="radio" name="abortos_consecutivos" value="si" <?php echo e(old('abortos_consecutivos') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="abortos_consecutivos" value="no" <?php echo e(old('abortos_consecutivos') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Antecedentes de 3 o más gestas</td>
                        <td><input type="radio" name="gestas" value="si" <?php echo e(old('gestas') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="gestas" value="no" <?php echo e(old('gestas') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Peso al nacer del último bebé < 2500g (5 lbs 8 onzas)</td>
                        <td><input type="radio" name="peso_bebe_2500g" value="si" <?php echo e(old('peso_bebe_2500g') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="peso_bebe_2500g" value="no" <?php echo e(old('peso_bebe_2500g') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Peso al nacer del último bebé > 4500g (9 lbs 9 onzas)</td>
                        <td><input type="radio" name="peso_bebe_4500g" value="si" <?php echo e(old('peso_bebe_4500g') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="peso_bebe_4500g" value="no" <?php echo e(old('peso_bebe_4500g') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Antecedentes de hipertensión o preeclampsia/eclampsia</td>
                        <td><input type="radio" name="hipertension" value="si" <?php echo e(old('hipertension') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="hipertension" value="no" <?php echo e(old('hipertension') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Cirugías previas en el tracto reproductor (miomectomía, conización, cesárea o cerclaje cervical)</td>
                        <td><input type="radio" name="cirugias_reproductor" value="si" <?php echo e(old('cirugias_reproductor') == 'si' ? 'checked' : ''); ?> required></td>
                        <td><input type="radio" name="cirugias_reproductor" value="no" <?php echo e(old('cirugias_reproductor') == 'no' ? 'checked' : ''); ?> required></td>
                    </tr>
                </tbody>
            </table>
            <a href="<?php echo e(route('registro.paso2')); ?>" class="btn btn-warning">Volver</a>
            <button type="submit" class="btn btn-success">Siguiente</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\antecedentes_obstetricos.blade.php ENDPATH**/ ?>