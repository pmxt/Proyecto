<!doctype html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Restablecer Contraseña</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">

    <!-- Bootstrap CSS v5.3.2 -->
    <link   
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
        crossorigin="anonymous"
    >
</head>
<body>
    <div class="wrapper">
        <!-- Logo de la empresa -->
        <div class="logo">
            <img src="<?php echo e(asset('imagenes/302464652_537376068387806_7427466127821357187_n.png')); ?>" alt="Logo">
        </div>

        <!-- Título de la vista -->
        <div class="text-center mt-4 name">
            Restablecer Contraseña
        </div>

        <!-- Mensaje de éxito al enviar el correo de restablecimiento -->
        <?php if(session('status')): ?>
            <div class="alert alert-success text-center mt-3">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <!-- Formulario para solicitar el restablecimiento de la contraseña -->
        <form action="<?php echo e(route('password.email')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <p>Ingresa tu correo electrónico</p>

            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span> 
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="email" value="<?php echo e(old('email')); ?>" placeholder="Correo electrónico" required autocomplete="email" autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary mt-3">
                    Solicitar
                </button>
            </div>
        </form>

        <!-- Enlaces para volver al inicio de sesión o crear una cuenta -->
        <div class="text-center fs-6 mt-3">
            <a href="<?php echo e(route('login')); ?>">Volver a Iniciar Sesión</a> o <a href="<?php echo e(route('register')); ?>">Crear cuenta</a>
        </div>
    </div>

    <!-- Bootstrap JavaScript Libraries -->
    <script
        src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4lJQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"
    ></script>

    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
        crossorigin="anonymous"
    ></script>
</body>
</html>
<?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\auth\passwords\email.blade.php ENDPATH**/ ?>