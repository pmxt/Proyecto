

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Listado de Pacientes</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Formulario de búsqueda -->
        <form action="<?php echo e(route('pacientes.listar')); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Buscar por CUI o nombre"
                    value="<?php echo e(request('search')); ?>">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
        </form>

        <!-- Tabla responsiva -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>CUI</th>
                        <th>Nombre</th>
                        <th>Edad</th>
                        <th>Teléfono</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($paciente->cui); ?></td>
                            <td><?php echo e($paciente->name); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($paciente->fecha_nacimiento)->age); ?> años</td>
                            <td><?php echo e($paciente->telefono); ?></td>
                            <td>
                                <!-- Botón con solo el ícono de WhatsApp -->
                                <a href="https://api.whatsapp.com/send?phone=<?php echo e($paciente->telefono); ?>&text=Hola%20<?php echo e(urlencode($paciente->name)); ?>%2C%20queremos%20confirmar%20tu%20próxima%20cita%20de%20control%20prenatal."
                                    target="_blank" class="btn btn-success btn-sm">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                                <!-- Botón de reportes solo con ícono -->
                                <a href="<?php echo e(route('mostrarVistaReporte', ['paciente' => $paciente->cui])); ?>"
                                    class="btn btn-secondary btn-sm" title="Generar Reporte">
                                    <i class="fa fa-file-pdf"></i> <!-- Ícono de Font Awesome para PDF -->
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Paginación -->
        <div class="d-flex justify-content-center">
            <?php echo e($pacientes->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\listado_pacientes.blade.php ENDPATH**/ ?>