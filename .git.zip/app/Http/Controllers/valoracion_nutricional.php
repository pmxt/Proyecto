<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class valoracion_nutricional extends Controller
{
    public function obtener(){
        
        
    }

    public function guardar(){

    }
    //
}
