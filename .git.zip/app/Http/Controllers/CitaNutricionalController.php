<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CitaNutricionalController extends Controller
{
    //
}
