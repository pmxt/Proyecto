<div>
    <input type="date" wire:model="fechaNacimiento" class="form-control" required>
    <input type="number" wire:model="edad" class="form-control" readonly>
</div>