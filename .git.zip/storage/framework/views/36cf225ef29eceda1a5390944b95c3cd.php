<!DOCTYPE html>
<html>

<head>
    <title>Reporte de Todos los Pacientes</title>
</head>

<body>
    <h1>Reporte de Todos los Pacientes del puesto de salud canton chotacaj totonicapan</h1>

    <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2>Datos del Paciente</h2>
        <p><strong>CUI:</strong> <?php echo e($paciente->cui); ?></p>
        <p><strong>Nombre:</strong> <?php echo e($paciente->name); ?></p>
        <p><strong>Edad:</strong> <?php echo e($paciente->edad); ?></p>
        <p><strong>Comunidad:</strong> <?php echo e($paciente->comunidad); ?></p>
        <p><strong>Escolaridd:</strong> <?php echo e($paciente->Escolaridad); ?></p>
        <p><strong>migrante:</strong> <?php echo e($paciente->migrante); ?></p>
        <p><strong>Telefono :</strong> <?php echo e($paciente->telefono); ?></p>





        <?php if($paciente->encargados->isNotEmpty()): ?>
            <h3>Encargados</h3>
            <?php $__currentLoopData = $paciente->encargados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encargado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><strong>Nombre del Encargado (Esposo):</strong> <?php echo e($encargado->nombreEsposo); ?></p>
                <p><strong>Edad del Encargado:</strong> <?php echo e($encargado->edad); ?></p>
                <p><strong>Ocupación del Encargado:</strong> <?php echo e($encargado->Ocupacion); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>Este paciente no tiene encargados registrados.</p>
        <?php endif; ?>

        <hr> <!-- Línea separadora entre pacientes -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($paciente->historial): ?>
        <h3>Historial Médico</h3>
        <p><strong>Diabetes:</strong> <?php echo e($paciente->historial->diabetes_a ? 'Sí' : 'No'); ?></p>
        <p><strong>Hipertensión:</strong> <?php echo e($paciente->historial->hipertension_a ? 'Sí' : 'No'); ?></p>
        <p><strong>Enfermedad del Corazón:</strong> <?php echo e($paciente->historial->corazon_a ? 'Sí' : 'No'); ?></p>
        <p><strong>Renal:</strong> <?php echo e($paciente->historial->renal_a ? 'Sí' : 'No'); ?></p>
        <p><strong>Drogas:</strong> <?php echo e($paciente->historial->drogas_a ? 'Sí' : 'No'); ?></p>
        <p><strong>Otra Condición:</strong> <?php echo e($paciente->historial->otra_a ? 'Sí' : 'No'); ?></p>
        <?php if($paciente->historial->especificacion): ?>
            <p><strong>Especificación de otra condición:</strong> <?php echo e($paciente->historial->especificacion); ?></p>
        <?php endif; ?>
        <p><strong>Fecha del Historial:</strong> <?php echo e($paciente->historial->fecha); ?></p>
        <p><strong>Responsable:</strong> <?php echo e($paciente->historial->responsable); ?></p>
    <?php else: ?>
        <p>No se ha registrado un historial médico para este paciente.</p>
    <?php endif; ?>




</body>

</html>
<?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\Reporte.blade.php ENDPATH**/ ?>