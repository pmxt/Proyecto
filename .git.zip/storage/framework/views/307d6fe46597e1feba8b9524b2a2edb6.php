

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-center">Gestión de Medicamentos</h2>

    <!-- Mensajes de éxito o error -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Formulario para agregar nuevos medicamentos -->
    <form action="<?php echo e(route('medicamentos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nombre">Nombre del Medicamento</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" required>
        </div>

        <div class="form-group">
            <label for="cantidad">Cantidad Disponible</label>
            <input type="number" name="cantidad" id="cantidad" class="form-control" value="<?php echo e(old('cantidad')); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Agregar Medicamento</button>
    </form>

    <hr>

    <!-- Tabla de medicamentos existentes -->
    <h4 class="text-center mt-4">Medicamentos Disponibles</h4>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($medicamento->nombre); ?></td>
                    <td><?php echo e($medicamento->cantidad); ?></td>
                    <td>
                       
                        <a href="<?php echo e(route('medicamentos.edit', $medicamento->id)); ?>" class="btn btn-sm" title="Editar">
                            <i class="fa fa-edit"></i>
                        </a>

                       
                        <button type="button" class="btn btn-sm" title="Eliminar"
                            onclick="confirmDelete(<?php echo e($medicamento->id); ?>, '<?php echo e($medicamento->nombre); ?>')">
                            <i class="fa fa-trash"></i>
                        </button>

                       
                        <form id="delete-form-<?php echo e($medicamento->id); ?>" action="<?php echo e(route('medicamentos.destroy', $medicamento->id)); ?>"
                            method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

   
    <?php echo e($medicamentos->links()); ?>

</div>


<script>
    function confirmDelete(id, name) {
        if(confirm('¿Estás seguro de que deseas eliminar el medicamento "' + name + '"?')) {
            document.getElementById('delete-form-' + id).submit();
        }
    }
</script>
<script>
    function confirmDelete(id, name) {
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                
                document.getElementById('delete-form-' + id).submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\medicamentos.blade.php ENDPATH**/ ?>