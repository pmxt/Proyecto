

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-center">Ingresar Datos para el Año <?php echo e($anio); ?></h2>

    <form method="POST" action="<?php echo e(route('guardarMes')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="anio" value="<?php echo e($anio); ?>">
    
        <label for="mes">Seleccionar Mes:</label>
        <select name="mes" id="mes" class="form-control">
            <?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mes); ?>"><?php echo e($mes); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    
        <label for="embarazos_esperados">Embarazos Esperados</label>
        <input type="number" name="embarazos_esperados" class="form-control" required>
    
        <label for="embarazos_realizados">Embarazos Realizados</label>
        <input type="number" name="embarazos_realizados" class="form-control" required>
    
        <button type="submit" class="btn btn-primary mt-3">Guardar Mes</button>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\ingresarMes.blade.php ENDPATH**/ ?>