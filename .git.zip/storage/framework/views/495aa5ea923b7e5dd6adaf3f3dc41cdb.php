<?php $__env->startSection('title'); ?>
    <?php echo e(config('adminlte.title')); ?>

    <?php if (! empty(trim($__env->yieldContent('subtitle')))): ?>
        | <?php echo $__env->yieldContent('subtitle'); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content_header'); ?>
    <?php if (! empty(trim($__env->yieldContent('content_header_title')))): ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>


        <h1 class="text-muted">
            <?php echo $__env->yieldContent('content_header_title'); ?>

            <?php if (! empty(trim($__env->yieldContent('content_header_subtitle')))): ?>
                <small class="text-dark">
                    <i class="fas fa-xs fa-angle-right text-muted"></i>
                    <?php echo $__env->yieldContent('content_header_subtitle'); ?>
                </small>
            <?php endif; ?>
        </h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
    <nav class="navbar navbar-expand navbar-light bg-light">
        <!-- Otros elementos de navegación -->

        <ul class="navbar-nav ml-auto">
            <!-- Botón de Logout personalizado -->
            <li class="nav-item">
                <a href="#" class="nav-link"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <img src="<?php echo e(asset('img/logout-icon.png')); ?>" alt="Logout" style="width: 20px; height: 20px;">
                    <span>Logout</span>
                </a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </ul>
    </nav>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
   
    <?php echo $__env->yieldContent('content_body'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>
    <div class="float-right">
        Version: <?php echo e(config('app.version', '1.0.0')); ?>

    </div>

    <strong>
        <a href="<?php echo e(config('app.company_url', '#')); ?>">
            <?php echo e(config('app.company_name', 'UMG')); ?>

        </a>
    </strong>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            // Add your common script logic here...
        });
    </script>
    <?php $__env->startPush('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('css'); ?>
    <style type="text/css">
         .card-header {
            border-bottom: none;
        }

        .card-title {
            font-weight: 600;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\app.blade.php ENDPATH**/ ?>