

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Lista de Usuarios</h2>

        <form method="GET" action="<?php echo e(route('listaUsuarios')); ?>">
            <input type="text" name="search" placeholder="Buscar por nombre o email" value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-outline-warning">Buscar</button>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered table-sm w-150 text-sm">
                <thead>
                    <tr>
                        <th class="col-12 col-md-4 ">Nombre</th>
                        <th class="col-12 col-md-4">Email</th>
                        <th class="col-12 col-md-4">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="min-w-44"><?php echo e($user->name); ?></td>
                            <td class="min-w-44"><?php echo e($user->email); ?></td>
                            <td>
                               
                                <a href=" <?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>

                               
                                <button type="button" class="btn btn-danger btn-sm"
                                    onclick="confirmDelete(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>')">
                                    <i class="fa fa-trash"></i>
                                </button>

                            
                                <form id="delete-form-<?php echo e($user->id); ?>" action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                    method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($users->links()); ?> 
        </div>
    </div>
    <script>
        function confirmDelete(id, name) {
            Swal.fire({
                title: '¿Estás seguro de que deseas eliminar el medicamento "' + name + '"?',
                text: "¡No podrás revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    
                    document.getElementById('delete-form-' + id).submit();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\listar_Usuarios.blade.php ENDPATH**/ ?>