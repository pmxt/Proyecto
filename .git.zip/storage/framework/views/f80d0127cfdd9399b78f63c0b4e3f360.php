<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Examen Físico</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #ffffff;
        }

        .container {
            width: 100%;
            margin-block-end: 10px;
            background-color: rgb(255, 255, 255);
            padding: 10px;
            border: 1px solid #242424;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 12px;
        }

        table, th, td {
            border: 1px solid black;
            padding: 5px;
            text-align: center;
        }

        th {
            background-color: #f0f0f0;
        }

        .section-title {
            font-weight: bold;
            background-color: #000000;
            color: #ffffff;
            text-align: center;
            padding: 5px;
        }
    </style>
</head>

<body>

    <div class="container">
        <h2>Reporte de Examen Físico</h2>

        <!-- Datos de la Paciente -->
        <div class="section-title">Datos de la Paciente</div>
        <table>
            <tr><th>Nombre</th><td><?php echo e($paciente->name); ?></td></tr>
            <tr><th>CUI</th><td><?php echo e($paciente->cui); ?></td></tr>
            <tr><th>Fecha de Nacimiento</th><td><?php echo e($paciente->fecha_nacimiento); ?></td></tr>
            <tr><th>Edad</th><td><?php echo e($paciente->edad); ?></td></tr>
        </table>

        <!-- Consulta Prenatal -->
        <div class="section-title">Consulta Prenatal</div>
        <table>
            <tr><th>Fecha de Consulta</th><td><?php echo e($consulta->fecha_consulta); ?></td></tr>
            <tr><th>Motivo de la Consulta</th><td><?php echo e($consulta->motivo_consulta); ?></td></tr>
        </table>

        <!-- Examen Físico -->
        <div class="section-title">Examen Físico</div>
        <?php if($examenFisico): ?>
        <table>
            <tr><th>Presión Arterial</th><td><?php echo e($examenFisico->presion_arterial); ?></td></tr>
            <tr><th>Temperatura Corporal</th><td><?php echo e($examenFisico->temperatura_corporal); ?></td></tr>
            <tr><th>Peso</th><td><?php echo e($examenFisico->peso); ?></td></tr>
            <tr><th>Frecuencia Respiratoria</th><td><?php echo e($examenFisico->frecuencia_respiratoria); ?></td></tr>
            <tr><th>Frecuencia Cardíaca Materna</th><td><?php echo e($examenFisico->frecuencia_cardiaca_materna); ?></td></tr>
            <tr><th>Estado General</th><td><?php echo e($examenFisico->estado_general); ?></td></tr>
            <tr><th>Examen Bucal</th><td><?php echo e($examenFisico->examen_bucal); ?></td></tr>
            <tr><th>Altura Uterina</th><td><?php echo e($examenFisico->altura_uterina); ?></td></tr>
            <tr><th>Movimientos Fetales</th><td><?php echo e($examenFisico->movimientos_fetales); ?></td></tr>
            <tr><th>Frecuencia Cardíaca Fetal</th><td><?php echo e($examenFisico->frecuencia_cardiaca_fetal); ?></td></tr>
            <tr><th>Leopoldo</th><td><?php echo e($examenFisico->leopoldo); ?></td></tr>
            <tr><th>Trazas de Sangre</th><td><?php echo e($examenFisico->trazas_sangre); ?></td></tr>
            <tr><th>Verrugas</th><td><?php echo e($examenFisico->verrugas); ?></td></tr>
            <tr><th>Flujo Vaginal</th><td><?php echo e($examenFisico->flujo_vaginal); ?></td></tr>
            <tr><th>Hemoglobina</th><td><?php echo e($examenFisico->hemoglobina); ?></td></tr>
            <tr><th>Grupo RH</th><td><?php echo e($examenFisico->grupo_rh); ?></td></tr>
            <tr><th>Orina</th><td><?php echo e($examenFisico->orina); ?></td></tr>
            <tr><th>Glicemia</th><td><?php echo e($examenFisico->glicemia); ?></td></tr>
            <tr><th>VDRL</th><td><?php echo e($examenFisico->vdrl); ?></td></tr>
            <tr><th>VIH</th><td><?php echo e($examenFisico->vih); ?></td></tr>
            <tr><th>Papanicolau</th><td><?php echo e($examenFisico->papanicolau); ?></td></tr>
            <tr><th>Infecciones</th><td><?php echo e($examenFisico->infecciones); ?></td></tr>
            <tr><th>Semanas de Embarazo</th><td><?php echo e($examenFisico->semanas_embarazo); ?></td></tr>
            <tr><th>Problemas Detectados</th><td><?php echo e($examenFisico->problemas_detectados); ?></td></tr>
        </table>
        <?php endif; ?>

        <!-- Signos y Síntomas de Peligro -->
        <div class="section-title">Signos y Síntomas de Peligro</div>
        <?php if($signosPeligro): ?>
        <table>
            <tr><th>Hemorragia Vaginal</th><td><?php echo e($signosPeligro->hemorragia_vaginal); ?></td></tr>
            <tr><th>Dolor de Cabeza Severo</th><td><?php echo e($signosPeligro->dolor_cabeza_severo); ?></td></tr>
            <tr><th>Visión Borrosa</th><td><?php echo e($signosPeligro->vision_borrosa); ?></td></tr>
            <tr><th>Convulsión</th><td><?php echo e($signosPeligro->convulsion); ?></td></tr>
            <tr><th>Dolor Abdominal Severo</th><td><?php echo e($signosPeligro->dolor_abdominal_severo); ?></td></tr>
            <tr><th>Presión Arterial Alta</th><td><?php echo e($signosPeligro->presion_arterial_alta); ?></td></tr>
            <tr><th>Fiebre</th><td><?php echo e($signosPeligro->fiebre); ?></td></tr>
            <tr><th>Presentación Fetal Anormal</th><td><?php echo e($signosPeligro->presentacion_fetal_anormal); ?></td></tr>
        </table>
        <?php endif; ?>

        <!-- Consejería -->
        <div class="section-title">Consejería</div>
        <?php if($consejeria): ?>
        <table>
            <tr><th>Alimentación</th><td><?php echo e($consejeria->alimentacion); ?></td></tr>
            <tr><th>Señales de Peligro durante el Embarazo</th><td><?php echo e($consejeria->senales_peligro_embarazo); ?></td></tr>
            <tr><th>Consejería sobre VIH</th><td><?php echo e($consejeria->consejeria_vih); ?></td></tr>
            <tr><th>Plan de Parto</th><td><?php echo e($consejeria->plan_parto); ?></td></tr>
            <tr><th>Plan de Emergencia</th><td><?php echo e($consejeria->plan_emergencia); ?></td></tr>
            <tr><th>Lactancia Materna</th><td><?php echo e($consejeria->lactancia_materna); ?></td></tr>
            <tr><th>Métodos de Planificación</th><td><?php echo e($consejeria->metodos_planificacion); ?></td></tr>
            <tr><th>Control Posparto</th><td><?php echo e($consejeria->control_posparto); ?></td></tr>
            <tr><th>Vacunación</th><td><?php echo e($consejeria->vacunacion); ?></td></tr>
        </table>
        <?php endif; ?>

        <!-- Medicamentos Asignados -->
        <div class="section-title">Medicamentos Asignados</div>
        <?php if($medicamentosAsignados->isNotEmpty()): ?>
        <table>
            <thead>
                <tr><th>Medicamento</th><th>Cantidad Asignada</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $medicamentosAsignados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($medicamento->medicamento): ?>
                        <tr>
                            <td><?php echo e($medicamento->medicamento->nombre); ?></td>
                            <td><?php echo e($medicamento->cantidad_asignada); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
            <p>No se encontraron medicamentos asignados.</p>
        <?php endif; ?>
    </div>

</body>

</html>
<?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\Reportes\examen.blade.php ENDPATH**/ ?>