

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-center">Registro de Consulta Prenatal</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
      <!-- Barra de progreso -->
      <?php if(isset($currentStep) && isset($totalSteps)): ?>
      <?php
          $progress = ($currentStep / $totalSteps) * 100;
      ?>
      <div class="progress mb-4">
          <div class="progress-bar" role="progressbar" style="width: <?php echo e($progress); ?>%;" 
              aria-valuenow="<?php echo e($progress); ?>" aria-valuemin="0" aria-valuemax="100">
              Paso <?php echo e($currentStep); ?> de <?php echo e($totalSteps); ?>

          </div>
      </div>
  <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(route('consulta.guardar')); ?>" method="GET">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="paciente">Seleccionar Paciente</label>
        <select name="paciente_cui" id="paciente" class="form-control" required onchange="this.form.submit()">
            <option value="">-- Selecciona una paciente --</option>
            <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($paciente->cui); ?>" <?php echo e(request('paciente_cui') == $paciente->cui ? 'selected' : ''); ?>>
                    <?php echo e($paciente->name); ?> - <?php echo e($paciente->cui); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</form>

<!-- Formulario para guardar la consulta -->
<form action="<?php echo e(route('consulta.guardar')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Mostrar los embarazos si ya se seleccionó un paciente -->
    <input type="hidden" name="paciente_cui" value="<?php echo e(request('paciente_cui')); ?>">
    
    <?php if(!empty($embarazos)): ?>
    <div class="form-group">
        <label for="embarazo_id">Seleccionar Embarazo:</label>
        <select id="embarazo_id" name="embarazo_id" class="form-control" required>
            <option value="">-- Seleccionar Embarazo --</option>
            <?php $__currentLoopData = $embarazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $embarazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($embarazo->id); ?>" <?php echo e(old('embarazo_id') == $embarazo->id ? 'selected' : ''); ?>>
                    Embarazo <?php echo e($embarazo->id); ?> - FPP: <?php echo e($embarazo->fecha_probable_parto); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>
        <div class="form-group">
            <label for="fecha_consulta">Fecha de la Consulta</label>
            <input type="date" id="fecha_consulta" name="fecha_consulta" class="form-control" value="<?php echo e(old('fecha_consulta', $datos['fecha_consulta'] ?? '')); ?>" required>
        </div>

        <div class="form-group">
            <label for="tipo_servicio">Tipo de Servicio</label>
            <select name="tipo_servicio" id="tipo_servicio" class="form-control" required>
                <option value="">Seleccione el tipo de servicio</option>
                <option value="PSF" <?php echo e(old('tipo_servicio', $datos['tipo_servicio'] ?? '') == 'PSF' ? 'selected' : ''); ?>>PSF</option>
                <option value="C/S 'A'" <?php echo e(old('tipo_servicio', $datos['tipo_servicio'] ?? '') == 'C/S \'A\'' ? 'selected' : ''); ?>>C/S 'A'</option>
                <option value="C/S 'B'" <?php echo e(old('tipo_servicio', $datos['tipo_servicio'] ?? '') == 'C/S \'B\'' ? 'selected' : ''); ?>>C/S 'B'</option>
                <option value="CENAPA" <?php echo e(old('tipo_servicio', $datos['tipo_servicio'] ?? '') == 'CENAPA' ? 'selected' : ''); ?>>CENAPA</option>
                <option value="CAP" <?php echo e(old('tipo_servicio', $datos['tipo_servicio'] ?? '') == 'CAP' ? 'selected' : ''); ?>>CAP</option>
                <option value="CAIMI" <?php echo e(old('tipo_servicio', $datos['tipo_servicio'] ?? '') == 'CAIMI' ? 'selected' : ''); ?>>CAIMI</option>
            </select>
        </div>

        <div class="form-group">
            <label for="area_salud">Área de Salud</label>
            <input type="text" name="area_salud" id="area_salud" class="form-control" value="<?php echo e(old('area_salud', $datos['area_salud'] ?? '')); ?>" placeholder="Ingrese el área de salud" required>
        </div>

        <div class="form-group">
            <label for="nombre_servicio">Distrito</label>
            <input type="text" name="nombre_servicio" id="nombre_servicio" class="form-control" value="<?php echo e(old('nombre_servicio', $datos['nombre_servicio'] ?? '')); ?>" placeholder="Ingrese el nombre del servicio" required>
        </div>

        <div class="form-group">
            <label for="motivo_consulta">Motivo de la Consulta</label>
            <select name="motivo_consulta" id="motivo_consulta" class="form-control" required>
                <option value="">Seleccione el motivo de la consulta</option>
                <option value="Embarazo" <?php echo e(old('motivo_consulta', $datos['motivo_consulta'] ?? '') == 'Embarazo' ? 'selected' : ''); ?>>Embarazo</option>
                <option value="Parto" <?php echo e(old('motivo_consulta', $datos['motivo_consulta'] ?? '') == 'Parto' ? 'selected' : ''); ?>>Parto</option>
                <option value="Postparto" <?php echo e(old('motivo_consulta', $datos['motivo_consulta'] ?? '') == 'Postparto' ? 'selected' : ''); ?>>Postparto</option>
            </select>
        </div>
        <div class="form-group">
            <label for="tipo_consulta">Tipo de Consulta</label>
            <input type="text" id="tipo_consulta" name="tipo_consulta" class="form-control" value="<?php echo e(old('tipo_consulta', $datos['tipo_consulta'] ?? '')); ?>" placeholder="Consulta prenatal, control rutinario, etc." required>
        </div>

        <!-- Botón para Enviar el Formulario -->
        <button type="submit" class="btn btn-success">Guardar y continuar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\consultas_prenatales.blade.php ENDPATH**/ ?>