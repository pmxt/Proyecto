

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Consejería</h2>

        <!-- error de registro -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <!-- Barra de progreso -->
        <?php if(isset($currentStep) && isset($totalSteps)): ?>
            <?php
                $progress = ($currentStep / $totalSteps) * 100;
            ?>
            <div class="progress mb-4">
                <div class="progress-bar" role="progressbar" style="width: <?php echo e($progress); ?>%;"
                    aria-valuenow="<?php echo e($progress); ?>" aria-valuemin="0" aria-valuemax="100">
                    Paso <?php echo e($currentStep); ?> de <?php echo e($totalSteps); ?>

                </div>
            </div>
        <?php endif; ?>
        <!-- registro correcto  -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('consejeria.guardar',['examenFisicoId' => $examenFisicoId])); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Consejería</th>
                        <th>Sí</th>
                        <th>No</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Alimentación durante el embarazo</td>
                        <td><input type="radio" name="alimentacion" value="SI" required
                                <?php echo e(old('alimentacion') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="alimentacion" value="NO" required
                                <?php echo e(old('alimentacion') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Señales de peligro durante el embarazo</td>
                        <td><input type="radio" name="senales_peligro_embarazo" value="SI" required
                                <?php echo e(old('senales_peligro_embarazo') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="senales_peligro_embarazo" value="NO" required
                                <?php echo e(old('senales_peligro_embarazo') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Consejería sobre propósito y prueba VIH</td>
                        <td><input type="radio" name="consejeria_vih" value="SI" required
                                <?php echo e(old('consejeria_vih') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="consejeria_vih" value="NO" required
                                <?php echo e(old('consejeria_vih') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Plan de parto</td>
                        <td><input type="radio" name="plan_parto" value="SI" required
                                <?php echo e(old('plan_parto') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="plan_parto" value="NO" required
                                <?php echo e(old('plan_parto') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Plan de emergencia familiar y comunitario</td>
                        <td><input type="radio" name="plan_emergencia" value="SI" required
                                <?php echo e(old('plan_emergencia') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="plan_emergencia" value="NO" required
                                <?php echo e(old('plan_emergencia') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Lactancia materna exclusiva/MIELA</td>
                        <td><input type="radio" name="lactancia_materna" value="SI" required
                                <?php echo e(old('lactancia_materna') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="lactancia_materna" value="NO" required
                                <?php echo e(old('lactancia_materna') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Otros métodos de planificación familiar</td>
                        <td><input type="radio" name="metodos_planificacion" value="SI" required
                                <?php echo e(old('metodos_planificacion') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="metodos_planificacion" value="NO" required
                                <?php echo e(old('metodos_planificacion') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Importancia del control posparto</td>
                        <td><input type="radio" name="control_posparto" value="SI" required
                                <?php echo e(old('control_posparto') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="control_posparto" value="NO" required
                                <?php echo e(old('control_posparto') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                    <tr>
                        <td>Vacunación y cuidados del recién nacido</td>
                        <td><input type="radio" name="vacunacion" value="SI" required
                                <?php echo e(old('vacunacion') == 'SI' ? 'checked' : ''); ?>></td>
                        <td><input type="radio" name="vacunacion" value="NO" required
                                <?php echo e(old('vacunacion') == 'NO' ? 'checked' : ''); ?>></td>
                    </tr>
                </tbody>
            </table>

            <button type="submit" class="btn btn-primary">Guardar Consejería</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\consejeria.blade.php ENDPATH**/ ?>