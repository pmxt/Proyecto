

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Asignar Suplementos a la Paciente</h2>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    
        <!-- Botón para descargar el PDF -->
        <a href="<?php echo e(route('reporte.descargar', ['consultaId' => session('consultaId')])); ?>" class="btn btn-secondary">
            <i class="fa fa-file-pdf-o"></i> Descargar PDF de la Cita
        </a>
    <?php endif; ?>
    

        <form
            action="<?php echo e(route('medicamentos.asignar.guardar', ['examenFisicoId' => $examenFisicoId, 'consultaId' => session('obtener1')['id']])); ?>"
            method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="embarazo_id" value="<?php echo e(session('embarazo_id')); ?>">
            <input type="hidden" name="paciente_cui" value="<?php echo e($paciente->cui); ?>">



            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Suplemento</th>
                        <th>Cantidad Disponible</th>
                        <th>Asignar</th>
                        <th>Cantidad a Asignar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($medicamento->nombre); ?></td>
                            <td><?php echo e($medicamento->cantidad); ?></td>
                            <td>
                                <?php if($medicamento->cantidad > 0): ?>
                                    <input type="checkbox" name="medicamentos[]" value="<?php echo e($medicamento->id); ?>">
                                <?php else: ?>
                                    <span class="text-danger">No Disponible</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <input type="number" name="cantidades[]" class="form-control" min="1"
                                    placeholder="Cantidad">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <button type="submit" class="btn btn-primary">Asignar Suplementos</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\asignar_medicamento.blade.php ENDPATH**/ ?>