<div>
    <input type="date" wire:model="fechaNacimiento" class="form-control" required>
    <input type="number" wire:model="edad" class="form-control" readonly>
</div><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\livewire\calculo1.blade.php ENDPATH**/ ?>