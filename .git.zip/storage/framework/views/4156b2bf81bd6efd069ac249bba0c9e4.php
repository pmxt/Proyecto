

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-center">Editar Medicamento</h2>

    <!-- Mostrar errores de validación -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Mostrar mensaje de éxito -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Formulario para editar el medicamento -->
    <form action="<?php echo e(route('medicamentos.update', $medicamento->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="nombre">Nombre del Medicamento</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre', $medicamento->nombre)); ?>" required>
        </div>

        <div class="form-group">
            <label for="cantidad">Cantidad Disponible</label>
            <input type="number" name="cantidad" id="cantidad" class="form-control" value="<?php echo e(old('cantidad', $medicamento->cantidad)); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Actualizar Medicamento</button>
    </form>

    <!-- Botón para regresar a la lista de medicamentos -->
    <div class="mt-3">
        <a href="<?php echo e(route('medicamentos.index')); ?>" class="btn btn-secondary">Regresar</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\medicamentoEdit.blade.php ENDPATH**/ ?>