

<?php $__env->startSection('title', 'Calendario'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilosU.css')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-muted">Calendario</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id='calendar'></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
   
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                editable: true,
                selectable: true,
                locale: 'es',
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                buttonText: {
                    today: 'Hoy',
                    month: 'Mes',
                    week: 'Semana',
                    day: 'Día'
                },
                events: '<?php echo e(route('calendario.citas')); ?>', 
                eventClick: function(info) {
                    
                    Swal.fire({
                        title: `Cita: ${info.event.title}`,
                        text: `¿Deseas realizar el control de la paciente ${info.event.extendedProps.paciente}?`,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Sí, realizar control',
                        cancelButtonText: 'Cancelar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            
                            window.location.href = `<?php echo e(route('consulta.Obtener')); ?>?id=${info.event.id}`;
                        }
                    });
                }
            });

            calendar.render();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        #calendar {
            max-width: 900px;
            margin: 0 auto;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto-Graduacion\resources\views\layouts\fullcalendar.blade.php ENDPATH**/ ?>